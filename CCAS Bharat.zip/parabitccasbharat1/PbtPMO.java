 
package parabitccasbharat1;

import java.sql.SQLException;

 
public class PbtPMO extends javax.swing.JDialog {
  PbtOffice oboffice;
  ParabitDBC db2;
   PbtOffice no;
   PbtLogin ol;
   int s;

    public PbtPMO(PbtLogin nob1) {
    super(nob1, true);
        
        initComponents();
       db2=new ParabitDBC();
        ol= nob1;


    }

   
   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btministry = new javax.swing.JButton();
        btdepartment = new javax.swing.JButton();
        btpmo = new javax.swing.JButton();

        btministry.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btministry.setText(" Ministry");

        btdepartment.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btdepartment.setText(" Census Department");
        btdepartment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btdepartmentActionPerformed(evt);
            }
        });

        btpmo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btpmo.setText(" PMO");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(btpmo, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69)
                .addComponent(btministry, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 94, Short.MAX_VALUE)
                .addComponent(btdepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btministry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btpmo, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
                    .addComponent(btdepartment, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(169, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btdepartmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btdepartmentActionPerformed
     try
     {
       // this.setVisible(false);
        s=ol.db1.rs1.getInt(7);
       // javax.swing.JOptionPane.showMessageDialog(null,s)
             
             new PbtOffice(this, ol).setVisible(true);
          //  no.btcfield.setEnabled(false);
          //  no.setVisible(true);
 
            
     }
     catch(Exception e)
     {
     
       System.out.print(e);
     
       }
     
     //oboffice= new PbtOffice(this,ol);
      
//    no.setVisible(true);
     
// TODO add your handling code here:

    }//GEN-LAST:event_btdepartmentActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
                 try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PbtPMO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
              // new PbtPMO().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btdepartment;
    public javax.swing.JButton btministry;
    public javax.swing.JButton btpmo;
    // End of variables declaration//GEN-END:variables
}
