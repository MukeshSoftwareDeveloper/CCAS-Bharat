 
package parabitccasbharat1;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

 
public class GovId extends javax.swing.JDialog {
    
 PbtLogin lg1;
 ParabitDBC db, db22;
 ParabitDBC1 db1,db2,db3,db4,db5,db6,db7,db8,db9,db10,db11,db12,db13;
  String  s,s1,t1=" ",t2=" ",t3=" ",g,t,dob,mob, dist,state,pin,vill,subdist, email ;
  String a=" ", b=" ",c=" ",d=" ",r;
  String  adno ,ad,pan ,src, arm, dl,cn,ps,pss,psv, rc, vi, mid, disa;
  String  pno, vno, psno,armid, btno, disid, rno,dno, gno,pvno, mrgno, pcno,fmid;
  
 
  
  
    public GovId(InformationOfHouse ob, PbtLogin lg) {
        super(ob,true);  
        initComponents();
        
         db = new ParabitDBC();
         db22= new ParabitDBC();
         db1 = new ParabitDBC1();
         db2 = new ParabitDBC1();
         db3 = new ParabitDBC1();
         db4 = new ParabitDBC1();
         db5 = new ParabitDBC1();
         db6 = new ParabitDBC1();
         db7 = new ParabitDBC1();
         db8 = new ParabitDBC1();
         db9 = new ParabitDBC1();
         db10 = new ParabitDBC1();
          db11 = new ParabitDBC1();
          db12 = new ParabitDBC1();
          db13 = new ParabitDBC1();
          
        lg1=lg;
                  
    }
    
  private void adharNo(String ad)
    {
     try {
         String qry="Insert into pbtcensus_household  (UID) values ('"+ad+"') ";
         db.stm.executeUpdate(qry);
     } catch (SQLException ex) {
         Logger.getLogger(GovId.class.getName()).log(Level.SEVERE, null, ex);
     }
    }
    
    
   private void   adharData(String adno)
    {
        try
        {
            String  qry1="Select * from pbtaadhar where ANo='"+adno+"' ";
                  System.out.println(qry1);
                             db1.rs1=db1.stm.executeQuery(qry1);
                              adharTf.setText(adno);   
             while(db1.rs1.next())
                       {
                                  
                           
                       }
         }catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
 
    }
 private void  PanData(String adno)
    {
                try
                    {
                         String  qry2="Select * from pbtpan where AdharNo='"+adno+"' ";
                          System.out.println(qry2);
                             db2.rs2=db2.stm.executeQuery(qry2);
                             adharTf.setText(adno);
                             
                                 while(db2.rs2.next())
                                  {
                                   
                                    pan=  db2.rs2.getString("PanNo");
                                    panTf.setText(pan);
                                      
                                   }
            
                     }catch(Exception ex)
                     {
                         ex.printStackTrace();
                     }
    }
 
 private void rmslicense(String adno)
 {
                   try
                   {
                         String  qry3="Select * from pbtarmslicense where AadhNo='"+adno+"' ";
                          System.out.println(qry3);
                             db3.rs3=db3.stm.executeQuery(qry3);
                               adharTf.setText(adno);
                                 while(db3.rs3.next())
                                  {
                                    
                                    arm=  db3.rs3.getString("LNo");
                                    armliTf.setText(arm);
                                    
           
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   }
 }
 
 private void derivingDl(String  adno)
 {
                     try
                   {
                         String  qry4="Select * from pbtdl where AdharNo='"+adno+"' ";
                          System.out.println(qry4);
                             db4.rs4=db4.stm.executeQuery(qry4);
                             adharTf.setText(adno);   
                                 while(db4.rs4.next())
                                  {
                     
                                    dl=  db4.rs4.getString("DLNumber");
                                    dlTf.setText(dl);
                                    
           
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   }
 }
 
 
 private void gasData(String adno)
 {
                 try
                   {
                         String  qry5="Select * from pbtgas where AdharNo='"+adno+"' ";
                          System.out.println(qry5);
                             db5.rs5=db5.stm.executeQuery(qry5);
                               adharTf.setText(adno); 
                                 while(db5.rs5.next())
                                  {
                                      
                                    cn=  db5.rs5.getString("CosNo");
                                    gasTf.setText(cn);
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   }  
 }
 
 private void   pensionData(String adno)
 {
             try
                   {
                         String  qry6="Select * from pbtpension where ANo='"+adno+"' ";
                             db6.rs6=db6.stm.executeQuery(qry6);
                               adharTf.setText(adno); 
                                 while(db6.rs6.next())
                                  {   
                                    ps=  db6.rs6.getString("PIDNo");
                                   psnTf.setText(ps);
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   } 
 }
 
 private void passport(String adno)
 {
      try
                   {
                         String  qry7="Select * from pbtpass  where ANo='"+adno+"' ";
                             db7.rs7=db7.stm.executeQuery(qry7);
                               adharTf.setText(adno); 
                                 while(db7.rs7.next())
                                  {   
                                    pss=  db7.rs7.getString("PassNo");
                                    passTf.setText(pss);
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   } 
 }
 
  private void policeVer(String adno)
 {
            try
                   {
                         String  qry8="Select * from pbt_police_ver  where AadNo='"+adno+"' ";
                             db8.rs8=db8.stm.executeQuery(qry8);
                               adharTf.setText(adno); 
                                 while(db8.rs8.next())
                                  {   
                                    psv=  db8.rs8.getString("PolVerNu");
                                    pvTf.setText(psv);
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   } 
 }
  private void rationCard(String adno)
 {
            try
                   {
                         String  qry9="Select * from pbt_rationcarddata  where AdhrNo='"+adno+"' ";
                             db9.rs9=db9.stm.executeQuery(qry9);
                               adharTf.setText(adno); 
                                 while(db9.rs9.next())
                                  {   
                                    rc=  db9.rs9.getString("RtnID");
                                    Rctf.setText(rc);
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   } 
 
 }
 private void votterId(String adno)
 {
            try
                   {
                       
                         String  qry10="Select * from pbtvid  where Ano='"+adno+"' ";
                             db10.rs10=db10.stm.executeQuery(qry10); 
                               adharTf.setText(adno); 
                                 while(db10.rs10.next())
                                  {   
                                    vi=  db10.rs10.getString("VID");
                                    vidTf.setText(vi);
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   } 
 }
 
  private void marrigeCf(String adno)
     {
            try
                   {
                       
                         String  qry11="Select * from pbtmarriage  where HbAadNo='"+adno+"' ";
                             db11.rs11=db11.stm.executeQuery(qry11); 
                               adharTf.setText(adno); 
                                 while(db11.rs11.next())
                                  {   
                                    mid=  db11.rs11.getString("MrgCNo");
                                    mrgTf.setText(vi);
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   } 
    }
  
    private void disAbility(String adno)
         {
            try
                   {
                       
                         String  qry12="Select * from pbtdisability  where Ano='"+adno+"' ";
                             db12.rs12=db12.stm.executeQuery(qry12); 
                               adharTf.setText(adno); 
                                 while(db12.rs12.next())
                                  {   
                                    disa=  db12.rs12.getString("RegNo");
                                    DisblityTf.setText(disa);
                                  } 
                   }catch(Exception ex)
                   {
                      ex.printStackTrace();
                   } 
       }
    
    private void submitData(String  uid)
    {  
  
       
      pno= panTf.getText();
      vno= vidTf.getText();
      psno= passTf.getText();
      armid= armliTf.getText();
      btno= birthTf.getText();
      disid= DisblityTf.getText();
       
       rno= Rctf.getText();
       dno= dlTf.getText();
       gno= gasTf.getText();
       pvno= pvTf.getText();
       mrgno= mrgTf.getText();
       pcno= psnTf.getText();
       fmid=famlyidtf.getText();
  
      
       try
      {
        String qry = "Update  pbtcensus_household set  RCardNo ='"+rno+"', GConsumerNo ='"+gno+"', DrivLicNo ='"+dno+"', ArmsUINo ='"+armid+"', BirthCertNo ='"+btno+"' , MarrCertNo ='"+mrgno+"', PoliceVerNo ='"+pvno+"', VID ='"+vno+"', Passport ='"+psno+"' , PensionID ='"+pcno+"', PWDID ='"+disid+"' , FSNo ='"+fmid+"'   where UID ='"+uid+"' ";
        System.out.println(qry );
         db22.stm.execute(qry); 
      }catch(SQLException ex)
      {
          ex.printStackTrace();
      }
   }
         
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bankDetails = new javax.swing.JButton();
        basicdetails = new javax.swing.JButton();
        healthdetailsbt = new javax.swing.JButton();
        educationdetailsbt = new javax.swing.JButton();
        empdetailsbt = new javax.swing.JButton();
        bthappiness = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        adharTf = new javax.swing.JTextField();
        panTf = new javax.swing.JTextField();
        vidTf = new javax.swing.JTextField();
        passTf = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        armliTf = new javax.swing.JTextField();
        birthTf = new javax.swing.JTextField();
        DisblityTf = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        Rctf = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        dlTf = new javax.swing.JTextField();
        gasTf = new javax.swing.JTextField();
        pvTf = new javax.swing.JTextField();
        mrgTf = new javax.swing.JTextField();
        psnTf = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        famlyidtf = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        Adhartf = new javax.swing.JTextField();
        BtOk = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        BtQRcode = new javax.swing.JButton();
        btsubmit = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bankDetails.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        bankDetails.setText(" Bank Details");
        bankDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bankDetailsActionPerformed(evt);
            }
        });
        getContentPane().add(bankDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(615, 890, 222, 95));

        basicdetails.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        basicdetails.setText(" Basic Details");
        basicdetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                basicdetailsActionPerformed(evt);
            }
        });
        getContentPane().add(basicdetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 764, 223, 95));

        healthdetailsbt.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        healthdetailsbt.setText(" Health Details");
        healthdetailsbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                healthdetailsbtActionPerformed(evt);
            }
        });
        getContentPane().add(healthdetailsbt, new org.netbeans.lib.awtextra.AbsoluteConstraints(614, 764, 223, 95));

        educationdetailsbt.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        educationdetailsbt.setText(" Educational Details");
        educationdetailsbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                educationdetailsbtActionPerformed(evt);
            }
        });
        getContentPane().add(educationdetailsbt, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 890, 222, 95));

        empdetailsbt.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        empdetailsbt.setText("Employee Work Details");
        empdetailsbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empdetailsbtActionPerformed(evt);
            }
        });
        getContentPane().add(empdetailsbt, new org.netbeans.lib.awtextra.AbsoluteConstraints(931, 764, 223, 95));

        bthappiness.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        bthappiness.setText(" Happiness");
        bthappiness.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bthappinessActionPerformed(evt);
            }
        });
        getContentPane().add(bthappiness, new org.netbeans.lib.awtextra.AbsoluteConstraints(932, 890, 222, 95));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Adhar Number");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 146, 147, 50));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText(" PAN Number");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 226, 147, 46));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText(" Passport Number ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 394, 170, 41));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Votter Id");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 315, 147, 46));

        adharTf.setText(" ");
        getContentPane().add(adharTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 148, 277, 50));

        panTf.setText(" ");
        getContentPane().add(panTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 228, 277, 47));

        vidTf.setText(" ");
        getContentPane().add(vidTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 317, 277, 46));

        passTf.setText(" ");
        getContentPane().add(passTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 391, 277, 51));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Arms License No");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 492, 170, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText(" Birth Certificate");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 566, 170, 49));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText(" Disability Number");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 643, 170, 48));

        armliTf.setText(" ");
        getContentPane().add(armliTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 480, 277, 50));

        birthTf.setText(" ");
        getContentPane().add(birthTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 566, 277, 53));

        DisblityTf.setText(" ");
        getContentPane().add(DisblityTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 645, 277, 48));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText(" Driving License No");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(638, 225, 170, 48));

        Rctf.setText(" ");
        getContentPane().add(Rctf, new org.netbeans.lib.awtextra.AbsoluteConstraints(859, 146, 305, 55));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setText(" Ration Card No");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(638, 144, 170, 54));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText(" Gas Costomer No");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(638, 318, 170, 40));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setText(" Police Verification");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(638, 393, 170, 43));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setText(" Marriage Certificate ");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(638, 492, 170, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setText(" Penssion No");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(638, 564, 170, 52));

        dlTf.setText(" ");
        getContentPane().add(dlTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(859, 226, 305, 50));

        gasTf.setText(" ");
        getContentPane().add(gasTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(859, 312, 305, 56));

        pvTf.setText(" ");
        getContentPane().add(pvTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(859, 390, 305, 53));

        mrgTf.setText(" ");
        getContentPane().add(mrgTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(859, 480, 305, 50));

        psnTf.setText(" ");
        getContentPane().add(psnTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(859, 565, 305, 54));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel14.setText(" Family Id");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(638, 644, 170, 46));

        famlyidtf.setText(" ");
        getContentPane().add(famlyidtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(859, 646, 305, 46));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel15.setText(" Enter Your Aadhar Number");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 66, 273, 56));

        Adhartf.setText(" ");
        Adhartf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdhartfActionPerformed(evt);
            }
        });
        getContentPane().add(Adhartf, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 67, 357, 58));

        BtOk.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        BtOk.setText(" OK");
        BtOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtOkActionPerformed(evt);
            }
        });
        getContentPane().add(BtOk, new org.netbeans.lib.awtextra.AbsoluteConstraints(718, 60, 128, 63));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel16.setText("Form Number");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 13, 178, 40));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel17.setText(" Details :-");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 706, 170, 51));

        BtQRcode.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        BtQRcode.setText(" QRCode Sccane");
        BtQRcode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtQRcodeActionPerformed(evt);
            }
        });
        getContentPane().add(BtQRcode, new org.netbeans.lib.awtextra.AbsoluteConstraints(891, 63, -1, 63));

        btsubmit.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btsubmit.setText(" Submit");
        btsubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btsubmitActionPerformed(evt);
            }
        });
        getContentPane().add(btsubmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 700, 220, 50));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void basicdetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_basicdetailsActionPerformed
               new BasicDetails(this,lg1).setVisible(true);         
    }//GEN-LAST:event_basicdetailsActionPerformed

    private void BtOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtOkActionPerformed
   
         s1= Adhartf.getText();
       
         adharData(s1);
         PanData(s1);
         rmslicense(s1);
         derivingDl(s1);
         gasData(s1);
         pensionData(s1);
         passport(s1);
         policeVer(s1);
         rationCard(s1);
         votterId(s1);
         marrigeCf(s1);
         disAbility(s1);
         
         adharNo(s1);   
         
    }//GEN-LAST:event_BtOkActionPerformed

    private void BtQRcodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtQRcodeActionPerformed
     // new  QRCodeScanner(this, lg1).setVisible(true);

    }//GEN-LAST:event_BtQRcodeActionPerformed

    private void AdhartfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdhartfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AdhartfActionPerformed

    private void healthdetailsbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_healthdetailsbtActionPerformed
         new HealthDetails(this,lg1).setVisible(true);
    }//GEN-LAST:event_healthdetailsbtActionPerformed

    private void empdetailsbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empdetailsbtActionPerformed
        new EmployeeDetails(this,lg1).setVisible(true);
    }//GEN-LAST:event_empdetailsbtActionPerformed

    private void educationdetailsbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_educationdetailsbtActionPerformed
            new EducationalDetails(this,lg1).setVisible(true);           }//GEN-LAST:event_educationdetailsbtActionPerformed

    private void bankDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bankDetailsActionPerformed
       new BankDetails(this,lg1).setVisible(true);
    }//GEN-LAST:event_bankDetailsActionPerformed

    private void bthappinessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bthappinessActionPerformed
        new HappinessDetails(this, lg1).setVisible(true);
    }//GEN-LAST:event_bthappinessActionPerformed

    private void btsubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btsubmitActionPerformed
        submitData(s1);
    }//GEN-LAST:event_btsubmitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GovId.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GovId.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GovId.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GovId.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
              //  new GovId().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Adhartf;
    private javax.swing.JButton BtOk;
    private javax.swing.JButton BtQRcode;
    private javax.swing.JTextField DisblityTf;
    private javax.swing.JTextField Rctf;
    private javax.swing.JTextField adharTf;
    private javax.swing.JTextField armliTf;
    private javax.swing.JButton bankDetails;
    private javax.swing.JButton basicdetails;
    private javax.swing.JTextField birthTf;
    private javax.swing.JButton bthappiness;
    private javax.swing.JButton btsubmit;
    private javax.swing.JTextField dlTf;
    private javax.swing.JButton educationdetailsbt;
    private javax.swing.JButton empdetailsbt;
    private javax.swing.JTextField famlyidtf;
    private javax.swing.JTextField gasTf;
    private javax.swing.JButton healthdetailsbt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField mrgTf;
    private javax.swing.JTextField panTf;
    private javax.swing.JTextField passTf;
    private javax.swing.JTextField psnTf;
    private javax.swing.JTextField pvTf;
    private javax.swing.JTextField vidTf;
    // End of variables declaration//GEN-END:variables
}
