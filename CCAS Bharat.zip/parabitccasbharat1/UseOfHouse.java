 
package parabitccasbharat1;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

 

/**
 *
 * @author MUKESH KUMAR
 */
public class UseOfHouse extends javax.swing.JDialog {
PbtLogin opl;
ParabitDBC db1,db2;
String n1=" ", n2=" ", n3=" ", n4=" ",n;
    /**
     * Creates new form UseOfHouse
     */
    public UseOfHouse(HouseListingForm ob7,PbtLogin plo) {
        super(ob7,true);
        
        initComponents();
        db1= new ParabitDBC();
        db2= new ParabitDBC(); 
        opl=plo;
        
        
        try
        {
            
        }catch(Exception ex)
        {
            
        }
    }

// To creating houselisting number  with this method
private void houseData()
{
        n1=HHnotf.getText();
        n2=landtf.getText();
        n3=mobtf.getText();
        n4=notetf.getText();
        
   try {       
        String qry = "Insert into pbtcensus_houselisting (HH_SNo, LatiLongi, OwnerPhnNo, Note )  values ('"+n1+"', '"+n2+"','"+n3+"', '"+n4+"') ";
        db1.stm.executeUpdate(qry);
        System.out.println(qry);
    } catch (SQLException ex) {
        Logger.getLogger(UseOfHouse.class.getName()).log(Level.SEVERE, null, ex);
    }
 
}
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Btresidance = new javax.swing.JButton();
        Btwork = new javax.swing.JButton();
        Btshoap = new javax.swing.JButton();
        BtCollegeSchool = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        landtf = new javax.swing.JTextField();
        notetf = new javax.swing.JTextField();
        HHnotf = new javax.swing.JTextField();
        mobtf = new javax.swing.JTextField();
        saveExit = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Btresidance.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        Btresidance.setText(" Residance");
        Btresidance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtresidanceActionPerformed(evt);
            }
        });
        getContentPane().add(Btresidance, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 284, 248, 107));

        Btwork.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        Btwork.setText(" Place of Workship");
        getContentPane().add(Btwork, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 284, 237, 107));

        Btshoap.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        Btshoap.setText(" OfficeShop");
        getContentPane().add(Btshoap, new org.netbeans.lib.awtextra.AbsoluteConstraints(626, 284, 233, 107));

        BtCollegeSchool.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        BtCollegeSchool.setText(" College/School");
        getContentPane().add(BtCollegeSchool, new org.netbeans.lib.awtextra.AbsoluteConstraints(961, 284, 259, 107));

        jButton5.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton5.setText(" Hospital");
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 444, 248, 102));

        jButton6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton6.setText(" Hotel/GestHouse");
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 444, 237, 102));

        jButton7.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton7.setText(" Other Use");
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(626, 444, 233, 102));

        jButton8.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton8.setText(" Vacent");
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(961, 444, 259, 102));

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setText(" Select Use Of House :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 201, 294, 65));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText(" HouseHold SNo.");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 13, 168, 48));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText(" Mobile No.");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 87, 140, 43));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText(" Latitude/Longitudinal");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 10, 182, 51));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("                   Note");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(602, 93, 170, 56));

        landtf.setText(" ");
        getContentPane().add(landtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 12, 400, 51));

        notetf.setText(" ");
        getContentPane().add(notetf, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 95, 400, 56));

        HHnotf.setText(" ");
        getContentPane().add(HHnotf, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 13, 290, 54));

        mobtf.setText(" ");
        getContentPane().add(mobtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 91, 290, 60));

        saveExit.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        saveExit.setText(" Save & Exit");
        saveExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveExitActionPerformed(evt);
            }
        });
        getContentPane().add(saveExit, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 180, 233, 65));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtresidanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtresidanceActionPerformed
       //  houseData(); 
        new  InformationOfHouse(this,opl).setVisible(true);
       
    }//GEN-LAST:event_BtresidanceActionPerformed

    private void saveExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveExitActionPerformed
       houseData();
    }//GEN-LAST:event_saveExitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UseOfHouse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UseOfHouse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UseOfHouse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UseOfHouse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            //    new UseOfHouse().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtCollegeSchool;
    private javax.swing.JButton Btresidance;
    private javax.swing.JButton Btshoap;
    private javax.swing.JButton Btwork;
    private javax.swing.JTextField HHnotf;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField landtf;
    private javax.swing.JTextField mobtf;
    private javax.swing.JTextField notetf;
    private javax.swing.JButton saveExit;
    // End of variables declaration//GEN-END:variables
}
