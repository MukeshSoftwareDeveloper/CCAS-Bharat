 
package parabitccasbharat1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement; 
import java.sql.ResultSet;

public class ParabitDBC {
  
    Connection con;
    Statement stm ;
    ResultSet rs, rs1,rs2,rs3,rs4,rs5,rs6,rs7,rs8,rs9;
    
ParabitDBC ()
    {
      try
        {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/parabitccasbharat1","root","");        
        stm = con.createStatement();
        
        }catch(Exception e)
            {
               System.out.println(".............." + e); 
              }
                    
    }
            
            
    public static void main(String arg[])
    {
    ParabitDBC ob = new ParabitDBC();
    }           
    
}
