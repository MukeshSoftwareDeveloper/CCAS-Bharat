 
package parabitccasbharat1;

import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.table.TableModel;

public class PbtNewAppointe extends javax.swing.JDialog {
     PbtLogin plo;
     ParabitDBC db1,db2,db3,db4;
     int s2,grade;
     String geid;
     String tp,state, ceid,dist,areadist, areacity, areastate;
     DefaultTableModel tm;
    
     
    public PbtNewAppointe(PbtComissoner ob3, PbtLogin  lob ) {
       super(ob3,true);
        
        initComponents();
        plo=lob;
         grade=plo.n;
         
        db1 = new ParabitDBC();
        db2 = new ParabitDBC(); 
        db3 = new ParabitDBC();
        db4 = new ParabitDBC();
      //  System.out.println(grade);
       try {
             //ceid="93425";
             ceid=lob.db1.rs1.getString("CEID");
             areadist=lob.db1.rs1.getString("AreaDist");
             areacity=lob.db1.rs1.getString("AreaCity");
             areastate=lob.db1.rs1.getString("AreaState");
             
         } catch (SQLException ex) {
             Logger.getLogger(PbtNewAppointe.class.getName()).log(Level.SEVERE, null, ex);
         }

          table();
          if(grade==1)
          {
              stateCombo();
          }
          else if(grade==2)
            {
               district();   
            }
          else 
              {
                  subdist();
              }
                  
        
    }
        
    public void update()
    {
        String qry = "Update  pbtemployeetable1 set Status='1' ,AreaState='"+state+"',AreaCity='All the city of state',AreaDist='all the District',CRepEmpID='"+ceid+"' ";
        System.out.println(qry+"mukesh");
     
        try
      {
         db3.stm.execute(qry); 
      }catch(SQLException ex)
      {
          ex.printStackTrace();
      }

    }
         
    public void update1()
    {
        String qry = "Update  pbtemployeetable1 set Status='1' ,AreaState='"+areastate+"',AreaDist='"+state+"',AreaCity='All Sub District', CRepEmpID='"+ceid+"'  ";
        System.out.println(qry+"mukesh");
     
        try
      {
         db3.stm.execute(qry); 
      }catch(SQLException ex)
      {
          ex.printStackTrace();
      }

    }
    
    public void update2()
    {
        String qry = "Update  pbtemployeetable1 set Status='1' ,AreaState='"+areastate+"',AreaDist='"+areadist+"',AreaCity='"+state+"', CRepEmpID='"+ceid+"'  ";
        System.out.println(qry+"mukesh");
     
        try
      {
         db3.stm.execute(qry); 
      }catch(SQLException ex)
      {
          ex.printStackTrace();
      }

    }
     private void table()
        {
         try {
             String qry4= "SELECT * FROM  pbtemployeetable1 where Grade = '"+(grade+1)+"' and Status=0";
             
             System.out.print(qry4);
             
             db4.rs4= db4.stm.executeQuery(qry4);
             DefaultTableModel ta = (DefaultTableModel)jTable1.getModel();
             ta.setRowCount(0);
             while(db4.rs4.next())
             {
                 Object o[] = {db4.rs4.getInt("SNo"), db4.rs4.getString("GEID"), db4.rs4.getString("EmpANo"), db4.rs4.getString("Empname"),
                     db4.rs4.getInt("Grade"), db4.rs4.getString("WorkExp"), db4.rs4.getString("WorkExpCensus"), db4.rs4.getString("EmpMob"),
                     db4.rs4.getString("EmpOffMob"), db4.rs4.getString("Email")};
                 ta.addRow(o);
             }  
         } catch (SQLException ex) {
             Logger.getLogger(PbtNewAppointe.class.getName()).log(Level.SEVERE, null, ex);
         }
        }
        
    private void stateCombo()
        {
             try
        {
            String qry1= "SELECT Distinct States FROM  pbtstates5"; 
            db1.rs1 = db1.stm.executeQuery(qry1);              
            while(db1.rs1.next())
            {
                   
                String s= db1.rs1.getString("States"); 
                 cobstate.addItem(s);
            }
        }catch(Exception ex)
           {
            System.out.println(ex);
           }
    
    }
       
    
  private void district()
         {
         try {
           //  cobdist.removeAllItems();
             String qry2= "SELECT Distinct  District FROM pbtstates5 where States='"+areastate+"' ";
             db2.rs2 = db2.stm.executeQuery(qry2);
             while(db2.rs2.next())
             {
                 String s1=db2.rs2.getString("District");
                 cobstate.addItem(s1);
             }
         } catch (SQLException ex) {
             Logger.getLogger(PbtNewAppointe.class.getName()).log(Level.SEVERE, null, ex);
         }
         }
         
       private void subdist()
          {
              try
              {
          //  cobsubdist.removeAllItems();
            String qry3= "SELECT  SubDist FROM pbtstates5 where District='"+areadist+"' ";
            db3.rs3= db3.stm.executeQuery(qry3);
            while(db3.rs3.next())
            {
                String s2=db3.rs3.getString("SubDist");
                cobstate.addItem(s2);
            }  
              }catch(Exception ex)
              {
                 ex.printStackTrace();
              }
          }
       
       
         public void populationState(String s1)
          {
             try
               {
                 String qry3=" SELECT sum(TPopulation) FROM  pbtstates5  where States='"+s1+"'";
                 System.out.println(qry3);
                              db4.rs3=db4.stm.executeQuery (qry3);
                              while(db4.rs3.next())
                              {
                                   tp=db4.rs3.getString("sum(TPopulation)");
                              }
              
              }catch(Exception ex)
               {
                 System.out.println(ex);
               }
            jLabel1.setText("Totalpopulation   "+tp);
        }
         
         
  public void populationDist(String s1)
          {
             try
               {
                 String qry3=" SELECT sum(TPopulation) FROM  pbtstates5  where District='"+s1+"'";
                 System.out.println(qry3);
                              db4.rs3=db4.stm.executeQuery (qry3);
                              while(db4.rs3.next())
                              {
                                   tp=db4.rs3.getString("sum(TPopulation)");
                              }
              
              }catch(Exception ex)
               {
                 System.out.println(ex);
               }
            jLabel1.setText("Totalpopulation   "+tp);
        }
             public void populationSubdist(String s1)
          {
             try
               {
                 String qry3=" SELECT sum(TPopulation) FROM  pbtstates5  where SubDist='"+s1+"' ";
                 System.out.println(qry3);
                              db4.rs3=db4.stm.executeQuery (qry3);
                              while(db4.rs3.next())
                              {
                                   tp=db4.rs3.getString("sum(TPopulation)");
                              }
              
              }catch(Exception ex)
               {
                 System.out.println(ex);
               }
            jLabel1.setText("Totalpopulation   "+tp);
        }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        cobstate = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Sno", "GEID", "EmpAno", "EmpName", "Grade", "WorkExp", "WorkExpSensus", "EmpMob", "EmpOffMob", "Email"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        cobstate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        cobstate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cobstateActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText(" TotalPopulation");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1204, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cobstate, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(cobstate, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if(evt.getClickCount()==2)
        {
           int i= jTable1.getSelectedRow();
           TableModel tb=jTable1.getModel();
           geid=tb.getValueAt(i,1).toString(); 
              if(grade==1)
                 {
                    update(); 
                 }
            else if(grade==2)
             {
                 update1();
             }
             else 
             {
                 update2();
             }  
       }
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void cobstateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cobstateActionPerformed
           state=cobstate.getSelectedItem().toString();
             if(grade==1)
                 {
                     populationState(state);
                 }
             else if(grade==2)
                 {
                     populationDist(state);
                 }
             else
             {
                 populationSubdist(state);
             }
             
    }//GEN-LAST:event_cobstateActionPerformed

     
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PbtNewAppointe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PbtNewAppointe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PbtNewAppointe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PbtNewAppointe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
           //    new PbtNewAppointe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cobstate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
