 
package parabitccasbharat1;
import javax.swing.table.DefaultTableModel;

 
public class PbtAppointedEmployee extends javax.swing.JDialog{
    ParabitDBC db;
    PbtLogin obl;
    DefaultTableModel tm;
    
     
    
    public PbtAppointedEmployee(PbtComissoner ob4, PbtLogin  lob  ) {
    super(ob4,true);   
    
     initComponents();
     
      db= new ParabitDBC();
      try
            {
              String ceid=lob.db1.rs1.getString( "CEID");
              String qur=" Select * from pbtemployeetable1 where Status=1 and CRepEmpID='"+ceid+"' ";
        
               db.rs1=db.stm.executeQuery(qur);
               DefaultTableModel ta = (DefaultTableModel)jTable1.getModel();
               ta.setRowCount(0);
               
                while(db.rs1.next())
               {
                Object m[] = {db.rs1.getInt("SNo"), db.rs1.getString("GEID"), db.rs1.getString("EmpANo"), db.rs1.getString("Empname"),
                               db.rs1.getInt("Grade"), db.rs1.getString("WorkExp"), db.rs1.getString("WorkExpCensus"), db.rs1.getString("EmpMob"),
                               db.rs1.getString("EmpOffMob"), db.rs1.getString("Email")};
                ta.addRow(m);
              }
    
            }
             catch(Exception ex) 
                 {
            
                 } 
     }

     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Sno", "GEID", "EmpAno", "EmpName", "Grade", "WorkExp", "WorkExpSensus", "EmpMob", "EmpOffMob", "Email"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1230, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1206, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 587, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(19, 19, 19)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

     
    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
          //     new PbtAppointedEmployee().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
