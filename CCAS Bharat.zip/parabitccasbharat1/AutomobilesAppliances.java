 
package parabitccasbharat1;

import java.sql.SQLException;

 
public class AutomobilesAppliances extends javax.swing.JDialog {
PbtLogin lo1;
ParabitDBC db1,db2,db3,db4,db5,db6,db7;
String hid, ref , rdo, fm ,pf;
int  bc, r2l, r4l, tcv;
int ch ,tv, tvs, mob, pc, bd, tbc ;
    /**
     * Creates new form AutomobilesAppliances
     */
    public AutomobilesAppliances(HouselistingDetails ob1, PbtLogin log2) {
        super(log2, true);
        initComponents();
        
        hid = ob1.HlSno; 
                
        db1 = new ParabitDBC();
        db2 = new ParabitDBC();
        db3 = new ParabitDBC();
        db4 = new ParabitDBC();
        db5 = new ParabitDBC();
        db6 = new ParabitDBC();
        db7 = new ParabitDBC();
        
        lo1=log2;
        
        coolerHeater();
        tvData();
        tvSignalData();
        mobileData();
        computerData();
        broadBandData();
        bicycleTypes();
    }
    
 public void coolerHeater()
 {
      try
         {
            String qry1= "SELECT Distinct Type  FROM  coolheatfact"; 
            db1.rs1 = db1.stm.executeQuery(qry1);              
            while(db1.rs1.next())
            {
                   
                String ds= db1.rs1.getString("Type"); 
                coolingDevicecombo.addItem(ds);
            }
         }catch(Exception ex)
           {
            System.out.println(ex);
           }
 }
 public void tvData()
 {
     try
         {
            String qry2= "SELECT Distinct TVTypes  FROM  tv "; 
            db2.rs2 = db2.stm.executeQuery(qry2);              
            while(db2.rs2.next())
            {
                   
                String tv= db2.rs2.getString("TVTypes"); 
                tvcombo.addItem(tv);
            }
         }catch(Exception ex)
           {
            System.out.println(ex);
           }
 }
     
  public void tvSignalData()
 {
     try
         {
            String qry3= "SELECT Distinct TypeTvSig  FROM  tvsig "; 
            db3.rs3 = db3.stm.executeQuery(qry3);              
            while(db3.rs3.next())
            {
                   
                String ts= db3.rs3.getString("TypeTvSig"); 
                tvsingnalcombo.addItem(ts);
            }
         }catch(Exception ex)
           {
            System.out.println(ex);
           }
 }
  
public void mobileData()
 {
     try
         {
            String qry4= "SELECT Distinct Types  FROM  phone "; 
            db4.rs4 = db4.stm.executeQuery(qry4);              
            while(db4.rs4.next())
            {
                   
                String m= db4.rs4.getString("Types"); 
                 mobcombo.addItem(m);
            }
         }catch(Exception ex)
           {
            System.out.println(ex);
           }
 }
  
 public void computerData()
 {
     try
         {
            String qry5= "SELECT Distinct PCType  FROM  pc "; 
            db5.rs5 = db5.stm.executeQuery(qry5);              
            while(db5.rs5.next())
            {
                   
                String pc= db5.rs5.getString("PCType"); 
                 pcCombo.addItem(pc);
            }
         }catch(Exception ex)
           {
            System.out.println(ex);
           }
 }
 public void broadBandData()
 {
     try
         {
            String qry6= "SELECT Distinct  Types  FROM telebroadband "; 
            db6.rs6 = db6.stm.executeQuery(qry6);              
            while(db6.rs6.next())
            {
                   
                String pc= db6.rs6.getString("Types"); 
                broadBandCom.addItem(pc);
            }
         }catch(Exception ex)
           {
            System.out.println(ex);
           }
 }
 
public void bicycleTypes()
 {
     try
         {
            String qry7= "SELECT Distinct  BicycleType  FROM typesofbicycle"; 
            db7.rs7 = db7.stm.executeQuery(qry7);              
            while(db7.rs7.next())
            {
                   
                String pc= db7.rs7.getString("BicycleType"); 
                bicycleTypescom.addItem(pc);
            }
         }catch(Exception ex)
           {
            System.out.println(ex);
           }
 }
 
public void  updateData()
{    
            bc=    (int) bicycle.getValue();
            r2l =   (int) twowheeler.getValue();
            r4l =    (int) fourWheeler.getValue();
            tcv =  (int) totaVehicle.getValue();
  
     try
      {
        String qry = "Update  pbtcensus_houselisting  set  CoolHeatFact='"+ch+"' , TV='"+tv+"'  ,TVSig='"+tvs+"'  ,Mob='"+mob+"'  ,PC='"+pc+"'  ,TeleBroadBand='"+bd+"'  ,TypesOfBicycle='"+tbc+"'  ,Refrigerator ='"+ref+"', Radio ='"+rdo+"', FM ='"+fm+"',  Bicycle='"+bc+"' ,R2Wheel='"+r2l+"'  ,R4Wheel='"+r4l+"'  ,TNoCommVeh='"+tcv+"' ,ParkingFact ='"+pf+"'  where  HL_SNo ='"+hid+"' ";
        System.out.println(qry);
         db1.stm.execute(qry); 
      }catch(SQLException ex)
      {
          ex.printStackTrace();
      }
      
}
  

 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        rbtrefYes = new javax.swing.JRadioButton();
        rbtrefNo = new javax.swing.JRadioButton();
        rbtredioYes = new javax.swing.JRadioButton();
        rbtradioNo = new javax.swing.JRadioButton();
        rbtfmYes = new javax.swing.JRadioButton();
        rbtfmNo = new javax.swing.JRadioButton();
        tvcombo = new javax.swing.JComboBox<>();
        tvsingnalcombo = new javax.swing.JComboBox<>();
        pcCombo = new javax.swing.JComboBox<>();
        coolingDevicecombo = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        broadBandCom = new javax.swing.JComboBox<>();
        mobcombo = new javax.swing.JComboBox<>();
        bicycle = new javax.swing.JSpinner();
        jButton1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        twowheeler = new javax.swing.JSpinner();
        fourWheeler = new javax.swing.JSpinner();
        totaVehicle = new javax.swing.JSpinner();
        jLabel15 = new javax.swing.JLabel();
        rbtpfYes = new javax.swing.JRadioButton();
        rbtpfNo = new javax.swing.JRadioButton();
        jLabel16 = new javax.swing.JLabel();
        bicycleTypescom = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText(" Refrigerator :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Radio :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("FM :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("TV :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 380, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("TV Singnal :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 450, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setText("Personal Computer :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 340, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setText("Tel Broad Band :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 430, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setText("Cooler/Heater :");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setText("Bicycle :");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 80, -1, -1));

        buttonGroup1.add(rbtrefYes);
        rbtrefYes.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbtrefYes.setText(" Yes");
        rbtrefYes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtrefYesActionPerformed(evt);
            }
        });
        getContentPane().add(rbtrefYes, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, -1, -1));

        buttonGroup1.add(rbtrefNo);
        rbtrefNo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbtrefNo.setText(" No");
        rbtrefNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtrefNoActionPerformed(evt);
            }
        });
        getContentPane().add(rbtrefNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 150, -1, -1));

        buttonGroup2.add(rbtredioYes);
        rbtredioYes.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbtredioYes.setText("Yes");
        rbtredioYes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtredioYesActionPerformed(evt);
            }
        });
        getContentPane().add(rbtredioYes, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, -1, -1));

        buttonGroup2.add(rbtradioNo);
        rbtradioNo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbtradioNo.setText(" No");
        rbtradioNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtradioNoActionPerformed(evt);
            }
        });
        getContentPane().add(rbtradioNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 200, -1, -1));

        buttonGroup3.add(rbtfmYes);
        rbtfmYes.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbtfmYes.setText(" Yes");
        rbtfmYes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtfmYesActionPerformed(evt);
            }
        });
        getContentPane().add(rbtfmYes, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, -1, -1));

        buttonGroup3.add(rbtfmNo);
        rbtfmNo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbtfmNo.setText(" No");
        rbtfmNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtfmNoActionPerformed(evt);
            }
        });
        getContentPane().add(rbtfmNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, -1, -1));

        tvcombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        tvcombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tvcomboActionPerformed(evt);
            }
        });
        getContentPane().add(tvcombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 360, 320, 52));

        tvsingnalcombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(tvsingnalcombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 440, 320, 50));

        pcCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(pcCombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 330, 330, 56));

        coolingDevicecombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(coolingDevicecombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 320, 49));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setText("Mobile :");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 530, -1, -1));

        broadBandCom.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(broadBandCom, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 420, 330, 53));

        mobcombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        mobcombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mobcomboActionPerformed(evt);
            }
        });
        getContentPane().add(mobcombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 520, 320, 54));
        getContentPane().add(bicycle, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 80, 88, 40));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton1.setText(" Submit & Exit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 620, 240, 60));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel11.setText("Electornic Appliances");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 10, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setText(" R2Wheel :");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 150, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel13.setText(" R4Wheel :");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 210, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel14.setText("Total no of commercial vehical :");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 280, -1, -1));
        getContentPane().add(twowheeler, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 140, 90, 40));
        getContentPane().add(fourWheeler, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 200, 90, 40));
        getContentPane().add(totaVehicle, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 270, 90, 40));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel15.setText(" Parking Facility : ");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, -1, 40));

        buttonGroup4.add(rbtpfYes);
        rbtpfYes.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbtpfYes.setText(" Yes");
        rbtpfYes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtpfYesActionPerformed(evt);
            }
        });
        getContentPane().add(rbtpfYes, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, -1, -1));

        buttonGroup4.add(rbtpfNo);
        rbtpfNo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbtpfNo.setText(" No");
        rbtpfNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtpfNoActionPerformed(evt);
            }
        });
        getContentPane().add(rbtpfNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 300, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel16.setText("Types Of Bicycle :");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 510, 160, 50));

        getContentPane().add(bicycleTypescom, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 500, 330, 60));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mobcomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mobcomboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mobcomboActionPerformed

    private void rbtrefYesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtrefYesActionPerformed
        ref = "Y";
    }//GEN-LAST:event_rbtrefYesActionPerformed

    private void rbtrefNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtrefNoActionPerformed
         ref ="N";
    }//GEN-LAST:event_rbtrefNoActionPerformed

    private void rbtredioYesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtredioYesActionPerformed
         rdo = "Y";
    }//GEN-LAST:event_rbtredioYesActionPerformed

    private void rbtradioNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtradioNoActionPerformed
         rdo = "N";
    }//GEN-LAST:event_rbtradioNoActionPerformed

    private void rbtpfYesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtpfYesActionPerformed
         pf = "Y";
    }//GEN-LAST:event_rbtpfYesActionPerformed

    private void rbtpfNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtpfNoActionPerformed
         pf = "N";
    }//GEN-LAST:event_rbtpfNoActionPerformed

    private void rbtfmYesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtfmYesActionPerformed
         fm = "Y";
    }//GEN-LAST:event_rbtfmYesActionPerformed

    private void rbtfmNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtfmNoActionPerformed
        fm = "N";
    }//GEN-LAST:event_rbtfmNoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
  
  String ch1 = (String)coolingDevicecombo.getSelectedItem();
        try
        {
            String qry11 ="Select * from  coolheatfact where Type='"+ch1+"'  ";
            db1.rs1=db1.stm.executeQuery(qry11);
            
            if(db1.rs1.next())
            {
                ch = db1.rs1.getInt("SNo");
            }
            
        }catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
  String tv1 = (String)tvcombo.getSelectedItem();
        try
        {
            String qry12 ="Select * from  tv  where TVTypes='"+tv1+"'  ";
            db2.rs2=db2.stm.executeQuery(qry12);
            
            if(db2.rs2.next())
            {
                tv = db2.rs2.getInt("SNo");
            }
            
        }catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
 String tvs1 = (String)tvsingnalcombo.getSelectedItem();
        try
        {
            String qry13 ="Select * from  tvsig  where TypeTvSig='"+tvs1+"'  ";
            db3.rs3=db3.stm.executeQuery(qry13);
            
            if(db3.rs3.next())
            {
                tvs = db3.rs3.getInt("SNo");
            }
            
        }catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
  String mob1 = (String)mobcombo.getSelectedItem();
        try
        {
            String qry14 ="Select * from  phone  where Types='"+mob1+"'  ";
            db4.rs4=db4.stm.executeQuery(qry14);
            
            if(db4.rs4.next())
            {
                mob = db4.rs4.getInt("SNo");
            }
            
        }catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
  String pc1 = (String)pcCombo.getSelectedItem();
        try
        {
            String qry15 ="Select * from  pc  where  PCType='"+pc1+"'  ";
            db5.rs5=db5.stm.executeQuery(qry15);
            
            if(db5.rs5.next())
            {
                pc = db5.rs5.getInt("SNo");
            }
            
        }catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
        
 String bd1 = (String)broadBandCom.getSelectedItem();
        try
        {
            String qry16 ="Select * from  telebroadband  where Types='"+bd1+"'  ";
            db6.rs6 = db6.stm.executeQuery(qry16);
            
            if(db6.rs6.next())
            {
                bd = db6.rs6.getInt("SNo");
            }
            
        }catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
   String tbc1 = (String)bicycleTypescom.getSelectedItem();
        try
        {
            String qry17 ="Select * from  typesofbicycle  where  BicycleType='"+tbc1+"'  ";
            db7.rs7=db7.stm.executeQuery(qry17);
            
            if(db7.rs7.next())
            {
                tbc = db7.rs7.getInt("SNo");
            }
            
        }catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
        
        updateData();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tvcomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tvcomboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tvcomboActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AutomobilesAppliances.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AutomobilesAppliances.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AutomobilesAppliances.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AutomobilesAppliances.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            //    new AutomobilesAppliances().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner bicycle;
    private javax.swing.JComboBox<String> bicycleTypescom;
    private javax.swing.JComboBox<String> broadBandCom;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.JComboBox<String> coolingDevicecombo;
    private javax.swing.JSpinner fourWheeler;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JComboBox<String> mobcombo;
    private javax.swing.JComboBox<String> pcCombo;
    private javax.swing.JRadioButton rbtfmNo;
    private javax.swing.JRadioButton rbtfmYes;
    private javax.swing.JRadioButton rbtpfNo;
    private javax.swing.JRadioButton rbtpfYes;
    private javax.swing.JRadioButton rbtradioNo;
    private javax.swing.JRadioButton rbtredioYes;
    private javax.swing.JRadioButton rbtrefNo;
    private javax.swing.JRadioButton rbtrefYes;
    private javax.swing.JSpinner totaVehicle;
    private javax.swing.JComboBox<String> tvcombo;
    private javax.swing.JComboBox<String> tvsingnalcombo;
    private javax.swing.JSpinner twowheeler;
    // End of variables declaration//GEN-END:variables
}
