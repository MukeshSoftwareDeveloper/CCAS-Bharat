/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parabitccasbharat1;

 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement; 
import java.sql.ResultSet;

public class ParabitDBC1 {
    
    Connection con;
    Statement stm ;
    ResultSet rs1,rs2,rs3,rs4,rs5,rs6,rs7,rs8,rs9,rs10,rs11,rs12;
    
 ParabitDBC1 ()
    {
      try
        {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/parabitccasbharat1_utill","root","");        
        stm = con.createStatement();
        
        }catch(Exception e)
            {
                 System.out.println(".............." + e);
             }
   }
 public static void main(String ar[])
 {
     ParabitDBC1 ob= new ParabitDBC1();
 }
}
