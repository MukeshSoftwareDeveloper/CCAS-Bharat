 
package parabitccasbharat1;
 
import java.sql.SQLException; 

public class BasicDetails extends javax.swing.JDialog {
  PbtLogin pln;
  ParabitDBC1 db2 ;
  ParabitDBC db1, db3, db4;
  String s,s1,t1=" ",t2=" ",t3=" ",g,t,dob1,mob, dist,state,pin,vill,subdist, email ,mrg, cat;
  String a=" ", b=" ",c=" ",d=" ",r,hlsno, gen, huid, rhd, hm, mb1, mb2, eml, ob1, age, rgn, cmt, catg, catyp, cst, rlg, mtg, hlg, chd, csu ;
    
   
 
     
    public BasicDetails(GovId ob2, PbtLogin lg2) {
       super(ob2,true); 
        
        initComponents();
         s=ob2.s1; 
         
        db1 = new ParabitDBC();
        db3 = new ParabitDBC();
        db4 = new ParabitDBC();
        db2 = new ParabitDBC1(); 
        
        
        pln=lg2;
      
     maritalStatus(); 
     categoryData(); 
     adharData(s);  
   
    }
    
 private void   adharData(String ad)
    {
        try
        {
            String  qry1="Select * from pbtaadhar where ANo='"+ad+"' ";
            System.out.println(qry1);
            db2.rs2=db2.stm.executeQuery(qry1);
            huidtf.setText(ad);
                               
         while(db2.rs2.next())
               {           
                         t1=  db2.rs2.getString("FstName");
                         t2= db2.rs2.getString("MidName");
                         t3=  db2.rs2.getString("LstName");
                          t=t1+" "+t2+" "+t3;
                         // nametf.setText(t);
                         
                          g= db2.rs2.getString("Gender"); 
                          mgen.setText(g);  
             
                          mob=db2.rs2.getString("MobNo");
                          headMobtf.setText(mob);
                          mobtf1.setText(mob);
         
                          dob1=db2.rs2.getString("DOB");
                          dobTf.setText(dob1);
                          
                           
                          a=db2.rs2.getString("HNo");
                          b=db2.rs2.getString("SRL");
                          c=db2.rs2.getString("ALS");
                          
                               r=a+",  "+b+",  "+c;
                            //   addresstf.setText(r);
                          
                          email=db2.rs2.getString("Email");
                          emailtf.setText(email);
                          
              
                       }
         }catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
    }
 
  private void categoryData()
   {
     try
         {
            String qry1= "SELECT Distinct Category  FROM  categories "; 
            db3.rs3 = db3.stm.executeQuery(qry1);              
            while(db3.rs3.next())
            {
                   
                String s= db3.rs3.getString("Category"); 
                catcombo.addItem(s);
            }
         }catch(Exception ex)
           {
            System.out.println(ex);
           }
    
    }
   private void maritalStatus()
   {
     try
         {
            String qry= "SELECT Distinct Current_Marital_Status  FROM  marital_status "; 
            db4.rs4 = db4.stm.executeQuery(qry);              
            while(db4.rs4.next())
            {
                   
                String s= db4.rs4.getString("Current_Marital_Status"); 
                maritalcombo.addItem(s);
            }
         }catch(Exception ex)
           {
            System.out.println(ex);
           }
    
    }
 
 
 private void basicDataUpdate()
 {
    cat =  catg;  
   huid=  huidtf.getText();
   rhd =  rheadtf.getText();
   hm =  headMobtf.getText();
  mb1 = mobtf1.getText();
  mb2 = mobtf2.getText();
  eml =  emailtf.getText();
 // ob1 =  dobTf.getText();
  age =   agetf.getText();
  rgn  =  religontf.getText();
  cmt =  comunitytf.getText();
 
 catyp =  catypetf.getText();
  cst=  casttf.getText();
  mtg =   motngtf.getText();
      
  rlg =   rlangtf.getText();
  hlg =   hlangutf.getText();
  chd =  choldbtf.getText();
  csu =   csurvedtf.getText();
  
  
  
  //DOB ='"+ob1+"',
      try{
              String qry = "Update  pbtcensus_household  set  HeadUID='"+huid+"', RelToHead='"+rhd+"', HeadRegMobNo ='"+hm +"', MobNo ='"+ mb1+"' , AltPhoneNo='"+mb2 +"',Email ='"+eml+"', Gender ='"+gen+"',   Age ='"+age+"', Religion = '"+rgn+"', Community ='"+cmt+"',Category ='"+cat+"',  CategoryTypeName='"+catyp +"' , MarStatus ='"+mrg+"', Cast ='"+cst +"', MTongue ='"+mtg +"', RWLang ='"+rlg +"', HomeLang ='"+ hlg+"', ChdnEvenBorn ='"+chd +"', NoOfChdnAliveLastYr ='"+csu +"'   where  UID='"+s+"' "; 
     
             System.out.println(qry);
             db1.stm.executeUpdate(qry);
                                        
          }catch(Exception ex)
           {
              ex.printStackTrace();
           }
                                          
     
 }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 32767));
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel2 = new javax.swing.JLabel();
        huidtf = new javax.swing.JTextField();
        headMobtf = new javax.swing.JTextField();
        rheadtf = new javax.swing.JTextField();
        mobtf1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        casttf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        motngtf = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        rlangtf = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        mobtf2 = new javax.swing.JTextField();
        emailtf = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        comunitytf = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        religontf = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        dobTf = new javax.swing.JTextField();
        agetf = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        mgen = new javax.swing.JRadioButton();
        fgen = new javax.swing.JRadioButton();
        ogen = new javax.swing.JRadioButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        hlangutf = new javax.swing.JTextField();
        choldbtf = new javax.swing.JTextField();
        csurvedtf = new javax.swing.JTextField();
        submit = new javax.swing.JButton();
        catypetf = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        catcombo = new javax.swing.JComboBox<>();
        maritalcombo = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("       Relation to Head :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 188, 50));

        huidtf.setText(" ");
        getContentPane().add(huidtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 100, 311, 53));

        headMobtf.setText(" ");
        getContentPane().add(headMobtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 270, 310, 60));

        rheadtf.setText(" ");
        getContentPane().add(rheadtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 311, 50));

        mobtf1.setText(" ");
        getContentPane().add(mobtf1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 360, 311, 54));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("               Mobile No :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 188, 43));

        casttf.setText(" ");
        getContentPane().add(casttf, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 370, 311, 54));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText(" Head UID :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 104, 46));

        motngtf.setText(" ");
        getContentPane().add(motngtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(1082, 448, 311, 52));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText(" Head Reg. Mobile No :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 188, 49));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("          Category :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 90, 143, 41));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("                Cast :");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(918, 373, 143, 52));

        rlangtf.setText(" ");
        getContentPane().add(rlangtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 530, 311, 50));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText("     Alternet Mobile No.");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 188, 46));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setText("                  Email Id :");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 524, 188, 47));

        mobtf2.setText(" ");
        getContentPane().add(mobtf2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 440, 311, 57));

        emailtf.setText(" ");
        getContentPane().add(emailtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(232, 521, 311, 57));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setText("                  Religion :");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 160, 184, 52));

        comunitytf.setText(" ");
        getContentPane().add(comunitytf, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 230, 309, 49));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setText("      Community :");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 230, 150, 42));

        religontf.setText(" ");
        getContentPane().add(religontf, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 160, 309, 51));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel14.setText("           Date Of  Birth :");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 618, -1, 65));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel15.setText("Age :");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 707, 52, 52));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel16.setText("      Marriage Status :");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 873, 176, 46));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel17.setText("        Gender :");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(81, 792, 119, 46));

        dobTf.setText(" ");
        getContentPane().add(dobTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(232, 618, 310, 65));

        agetf.setText(" ");
        getContentPane().add(agetf, new org.netbeans.lib.awtextra.AbsoluteConstraints(232, 707, 118, 57));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel18.setText("Form Of Basic Details");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 20, 318, 44));

        buttonGroup1.add(mgen);
        mgen.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        mgen.setText(" Male");
        mgen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mgenActionPerformed(evt);
            }
        });
        getContentPane().add(mgen, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 800, -1, -1));

        buttonGroup1.add(fgen);
        fgen.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fgen.setText(" Female");
        fgen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fgenActionPerformed(evt);
            }
        });
        getContentPane().add(fgen, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 800, -1, -1));

        buttonGroup1.add(ogen);
        ogen.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ogen.setText("Other");
        ogen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ogenActionPerformed(evt);
            }
        });
        getContentPane().add(ogen, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 800, -1, -1));

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel19.setText("        Mother Tounge :");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(877, 448, 184, 48));

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel20.setText("Read Write Language :");
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(877, 524, 184, 54));

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel21.setText("       Home Language :");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(877, 607, 184, 62));

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel22.setText("               Child Born :");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 700, -1, 52));

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel24.setText(" No Of Children Survived :");
        getContentPane().add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 780, -1, 47));

        hlangutf.setText(" ");
        getContentPane().add(hlangutf, new org.netbeans.lib.awtextra.AbsoluteConstraints(1082, 613, 311, 55));

        choldbtf.setText(" ");
        getContentPane().add(choldbtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 700, 314, 55));

        csurvedtf.setText(" ");
        getContentPane().add(csurvedtf, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 780, 314, 54));

        submit.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        submit.setText(" Save/Submit");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });
        getContentPane().add(submit, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 900, 220, 60));

        catypetf.setText(" ");
        getContentPane().add(catypetf, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 300, 310, 50));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText(" Category Type :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 300, 140, 40));

        catcombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        catcombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                catcomboActionPerformed(evt);
            }
        });
        getContentPane().add(catcombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 80, 310, 60));

        maritalcombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        maritalcombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maritalcomboActionPerformed(evt);
            }
        });
        getContentPane().add(maritalcombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 870, 330, 60));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mgenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mgenActionPerformed

       gen="M";
    }//GEN-LAST:event_mgenActionPerformed

    private void fgenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fgenActionPerformed
        gen="F";
    }//GEN-LAST:event_fgenActionPerformed

    private void ogenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ogenActionPerformed
        gen="O";
    }//GEN-LAST:event_ogenActionPerformed

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
                  basicDataUpdate();
    }//GEN-LAST:event_submitActionPerformed

    private void catcomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_catcomboActionPerformed
     catg= catcombo.getSelectedItem().toString();
    }//GEN-LAST:event_catcomboActionPerformed

    private void maritalcomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maritalcomboActionPerformed
          mrg= maritalcombo.getSelectedItem().toString();
    }//GEN-LAST:event_maritalcomboActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BasicDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BasicDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BasicDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BasicDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
             //   new BasicDetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField agetf;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JTextField casttf;
    private javax.swing.JComboBox<String> catcombo;
    private javax.swing.JTextField catypetf;
    private javax.swing.JTextField choldbtf;
    private javax.swing.JTextField comunitytf;
    private javax.swing.JTextField csurvedtf;
    private javax.swing.JTextField dobTf;
    private javax.swing.JTextField emailtf;
    private javax.swing.JRadioButton fgen;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JTextField headMobtf;
    private javax.swing.JTextField hlangutf;
    private javax.swing.JTextField huidtf;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JComboBox<String> maritalcombo;
    private javax.swing.JRadioButton mgen;
    private javax.swing.JTextField mobtf1;
    private javax.swing.JTextField mobtf2;
    private javax.swing.JTextField motngtf;
    private javax.swing.JRadioButton ogen;
    private javax.swing.JTextField religontf;
    private javax.swing.JTextField rheadtf;
    private javax.swing.JTextField rlangtf;
    private javax.swing.JButton submit;
    // End of variables declaration//GEN-END:variables

    
}
