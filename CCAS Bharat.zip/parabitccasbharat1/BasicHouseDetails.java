 
package parabitccasbharat1;

import java.sql.SQLException;

 
public class BasicHouseDetails extends javax.swing.JDialog{
 PbtLogin log;
 ParabitDBC db1,db2,db3,db4, db5,db6,db7,db8,db9;
 String hid, tda ,tpa, nptree, ntree, blta, plta ;
 int fdy, dm , sd=0, ch=0, uh=0, kh=0, wl=0, fr=0, rf=0 , cf=0, cfl=0 ;
    
    public BasicHouseDetails(HouselistingDetails obj, PbtLogin log1) {
        super(log1, true);
        initComponents();
       hid =  obj.HlSno;
        
       db1 = new ParabitDBC();
       db2 = new ParabitDBC();
       db3 = new ParabitDBC();
       db4 = new ParabitDBC();
       db5 = new ParabitDBC();
       
       db6 = new ParabitDBC();
       db7 = new ParabitDBC();
       db8 = new ParabitDBC();
       db9 = new ParabitDBC(); 
        log=log1;
        
        typeHouseCombo();
        conditionOfHouse();
        useOfhouse();
        kitchenTypes();
        cookFuel();
        wall();
        floor();
        roof();
        
        
        
    }

  public void  typeHouseCombo()
    {
         try
        {
            String qry1= "SELECT Distinct HouseType  FROM  typeofhouse"; 
                  System.out.println(qry1);
                             db1.rs1=db1.stm.executeQuery(qry1);
                               
                  while(db1.rs1.next())
                       {
                         String s= db1.rs1.getString("HouseType");
                         typehousecombo.addItem(s);
                        }
         } catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
       }
  
  public void conditionOfHouse()
  {
      
         try
        {
            String qry2= "SELECT Distinct conditionofhouse  FROM  cndtofhouse"; 
                  System.out.println(qry2);
                             db2.rs2=db2.stm.executeQuery(qry2);
                               
                  while(db2.rs2.next())
                       {
                         String cd= db2.rs2.getString("conditionofhouse");
                         condofhs.addItem(cd);
                        }
         } catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
  }
  
  public void useOfhouse()
  {
       try
        {
            String qry3= "SELECT Distinct  UseHouse  FROM  useofhouse"; 
                  System.out.println(qry3);
                             db3.rs3=db3.stm.executeQuery(qry3);
                               
                  while(db3.rs3.next())
                       {
                         String uh= db3.rs3.getString("UseHouse");
                         useofhouse.addItem(uh);
                        }
         } catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
  }
  
 public void kitchenTypes()
  {
            try
        {
            String qry4= "SELECT Distinct KitchenAvailable   FROM  kitchen"; 
                  System.out.println(qry4);
                             db4.rs4=db4.stm.executeQuery(qry4);
                               
                  while(db4.rs4.next())
                       {
                         String kt= db4.rs4.getString("KitchenAvailable");
                        kitchencombo.addItem(kt);
                        }
         } catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
  }
 
public void cookFuel()
{
               try
        {
            String qry5= "SELECT Distinct  MainFuelUsedForKithen   FROM  cookfuel"; 
                  System.out.println(qry5);
                             db5.rs5=db5.stm.executeQuery(qry5);
                               
                  while(db5.rs5.next())
                       {
                         String cf= db5.rs5.getString("MainFuelUsedForKithen");
                        cookfuelcombo.addItem(cf);
                        }
         } catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
}
public void wall()
{
            try
        {
            String qry6= "SELECT Distinct  TypeOfWall  FROM  wall"; 
                  System.out.println(qry6);
                             db6.rs6=db6.stm.executeQuery(qry6);
                               
                  while(db6.rs6.next())
                       {
                         String wl= db6.rs6.getString("TypeOfWall");
                        wallcombo.addItem(wl);
                        }
         } catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
}
public void floor()
{
            try
        {
            String qry7= "SELECT Distinct  TypesOfFloor  FROM  floor"; 
                  System.out.println(qry7);
                             db7.rs7=db7.stm.executeQuery(qry7);
                               
                  while(db7.rs7.next())
                       {
                         String wl= db7.rs7.getString("TypesOfFloor");
                        floorcombo.addItem(wl);
                        }
         } catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
}

public void roof()
{
            try
        {
            String qry8= "SELECT Distinct  TypeOfRoof  FROM  roof"; 
                  System.out.println(qry8);
                             db8.rs8=db8.stm.executeQuery(qry8);
                               
                  while(db8.rs8.next())
                       {
                         String wl= db8.rs8.getString("TypeOfRoof");
                        roofcombo.addItem(wl);
                        }
         } catch(Exception ex)
                    {
                       ex.printStackTrace();
                     }
}
public void houseData()
{
 fdy =   foundationYear.getValue();
 dm =  (int) Droom.getValue();
 plta  =   plotareatf.getText();
 blta =    builtareatf.getText();
ntree =    nooftreetf.getText();
nptree =  nooftreeprot.getText();
  tda =    totalDanimals.getText();
  tpa =    totalPetanimal.getText();
    
     try
      {
        String qry9 = "Update  pbtcensus_houselisting  set  TypeOfHouse='"+sd+"' , FndYrOfHouse='"+fdy+"' ,CndtOfHouse ='"+ch+"',UseOfHouse='"+uh+"'  ,Kitchen='"+kh+"'   ,Wall='"+wl+"'  ,Floor='"+fr+"' ,Roof='"+rf+"'  ,CookFuel='"+cfl+"'  ,PlotArea='"+plta+"' ,BuiltUpArea='"+blta+"' ,NoOfTrees='"+ntree+"'  ,NoOfProtTrees='"+nptree+"'  ,TypeOfDomAnimalWithNo='"+tda+"'  ,TypeOfPetAnimalWithNo='"+tpa+"'  where  HL_SNo ='"+hid+"' ";
        System.out.println(qry9);
         db9.stm.execute(qry9); 
      }catch(SQLException ex)
      {
          ex.printStackTrace();
      }
}
        /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Droom = new javax.swing.JSpinner();
        condofhs = new javax.swing.JComboBox<>();
        useofhouse = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        kitchencombo = new javax.swing.JComboBox<>();
        cookfuelcombo = new javax.swing.JComboBox<>();
        plotareatf = new javax.swing.JTextField();
        builtareatf = new javax.swing.JTextField();
        nooftreetf = new javax.swing.JTextField();
        nooftreeprot = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        typehousecombo = new javax.swing.JComboBox<>();
        foundationYear = new com.toedter.calendar.JYearChooser();
        submitbt = new javax.swing.JButton();
        wallcombo = new javax.swing.JComboBox<>();
        floorcombo = new javax.swing.JComboBox<>();
        roofcombo = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        totalDanimals = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        totalPetanimal = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Basic House Details");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(424, 13, 313, 34));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText(" Roof :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 750, 70, 40));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("       Floor :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 660, 100, 40));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("     Wall :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 570, 90, 50));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("       Dwelling Room :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(692, 170, 180, 50));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText(" Foundation Year Of House :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, 40));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("     Condition Of House :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, -1, 40));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("           Use Of House :");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, -1, 40));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setText("             Buit Up Area :");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 350, -1, 50));
        getContentPane().add(Droom, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 170, 130, 50));

        condofhs.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(condofhs, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 280, 330, 50));

        useofhouse.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(useofhouse, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 380, 330, 50));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText(" Plot Area :");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 260, 90, 40));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setText(" No Of Trees:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 440, -1, 40));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setText("  No Of Protected Trees :");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 530, -1, 40));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setText("Type Of Domestic Animal With No : ");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 630, -1, 40));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel14.setText("Types Of Pet Animal With No :");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 730, -1, 50));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel15.setText(" Cooking Fuel :");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 80, -1, 40));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel16.setText(" Kitchen :");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 470, 80, 40));

        kitchencombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(kitchencombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 470, 330, 50));

        cookfuelcombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(cookfuelcombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 80, 340, 50));

        plotareatf.setText(" ");
        getContentPane().add(plotareatf, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 260, 340, 50));

        builtareatf.setText(" ");
        getContentPane().add(builtareatf, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 350, 340, 50));

        nooftreetf.setText(" ");
        getContentPane().add(nooftreetf, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 440, 340, 50));

        nooftreeprot.setText(" ");
        getContentPane().add(nooftreeprot, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 530, 340, 50));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel17.setText(" Type Of House :");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, -1, 40));

        typehousecombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(typehousecombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, 330, 50));
        getContentPane().add(foundationYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, 240, 60));

        submitbt.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        submitbt.setText(" Submit & Exit");
        submitbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitbtActionPerformed(evt);
            }
        });
        getContentPane().add(submitbt, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 810, 220, 60));

        getContentPane().add(wallcombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 570, 370, 50));

        getContentPane().add(floorcombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 660, 370, 50));

        getContentPane().add(roofcombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 750, 370, 50));

        totalDanimals.setColumns(20);
        totalDanimals.setRows(5);
        jScrollPane1.setViewportView(totalDanimals);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 610, 340, 70));

        totalPetanimal.setColumns(20);
        totalPetanimal.setRows(5);
        jScrollPane2.setViewportView(totalPetanimal);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 720, 340, 70));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void submitbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitbtActionPerformed
        
        String cm = (String)typehousecombo.getSelectedItem();
        
        try
        {
            String query12 ="SELECT * From  typeofhouse  where  HouseType = '"+cm+"' ";
            db1.rs1=db1.stm.executeQuery(query12);
            if(db1.rs1.next())
            {
                 sd = db1.rs1.getInt("SNo");
            }
            
        }
        catch(Exception sd)
        {
            
        }
        
    String cm1 = (String)condofhs.getSelectedItem();
        
        try
        {
            String query13 ="SELECT  *  From  cndtofhouse  where  conditionofhouse ='"+cm1+"' ";
            db2.rs2=db2.stm.executeQuery(query13);
            if(db2.rs2.next())
            {
                 ch = db2.rs2.getInt("SNo");
            }
            
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
        String cm2 = (String)useofhouse.getSelectedItem();
        
        try
        {
            String query14 ="SELECT * From  useofhouse  where  UseHouse  = '"+cm2+"' ";
            db3.rs3=db3.stm.executeQuery(query14);
            if(db3.rs3.next())
            {
                 uh = db3.rs3.getInt("SNo");
            }
            
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
       String cm3 = (String)kitchencombo.getSelectedItem();
        try
        {
            String query15 ="SELECT * From  kitchen  where  KitchenAvailable = '"+cm3+"' ";
            db4.rs4=db4.stm.executeQuery(query15);
            if(db4.rs4.next())
            {
                 kh = db4.rs4.getInt("SNo");
            }   
        } 
        catch(Exception ex)
        {
           ex.printStackTrace();
        }
        
          String cm4 = (String)wallcombo.getSelectedItem();
        try
        {
            String query16 ="SELECT * From  wall  where  TypeOfWall = '"+cm4+"' ";
            db6.rs6=db6.stm.executeQuery(query16);
            if(db6.rs6.next())
            {
                 wl = db6.rs6.getInt("SNo");
            }
            
        } 

        catch(Exception ex)
        {
           ex.printStackTrace();
        }
        
        String cm5 = (String)floorcombo.getSelectedItem();
        try
        {
            String query17 ="SELECT * From   floor  where  TypesOfFloor = '"+cm5+"' ";
            db7.rs7=db7.stm.executeQuery(query17);
            if(db7.rs7.next())
            {
                 fr = db7.rs7.getInt("SNo");
            }
            
        }
        catch(Exception ex)
        {
           ex.printStackTrace();
        }
        
           String cm6 = (String)roofcombo.getSelectedItem();
        try
        {
            String query18 ="SELECT * From  roof  where  TypeOfRoof = '"+cm6+"' ";
            db8.rs8=db8.stm.executeQuery(query18);
            if(db8.rs8.next())
            {
                 rf = db8.rs8.getInt("SNo");
            }
            
        }
        catch(Exception ex)
        {
           ex.printStackTrace();
        }
        
      String cm7 = (String)cookfuelcombo.getSelectedItem();
        try
        {
            String query19 ="SELECT * From  cookfuel  where  MainFuelUsedForKithen  = '"+cm7+"' ";
            db5.rs5=db5.stm.executeQuery(query19);
            if(db5.rs5.next())
            {
                 cfl = db5.rs5.getInt("SNo");
            }
            
            
        }
        catch(Exception ex)
        {
           ex.printStackTrace();
        }
        // for updating data in houselisting table
        houseData();
          
    }//GEN-LAST:event_submitbtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BasicHouseDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BasicHouseDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BasicHouseDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BasicHouseDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
           //     new BasicHouseDetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner Droom;
    private javax.swing.JTextField builtareatf;
    private javax.swing.JComboBox<String> condofhs;
    private javax.swing.JComboBox<String> cookfuelcombo;
    private javax.swing.JComboBox<String> floorcombo;
    private com.toedter.calendar.JYearChooser foundationYear;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox<String> kitchencombo;
    private javax.swing.JTextField nooftreeprot;
    private javax.swing.JTextField nooftreetf;
    private javax.swing.JTextField plotareatf;
    private javax.swing.JComboBox<String> roofcombo;
    private javax.swing.JButton submitbt;
    private javax.swing.JTextArea totalDanimals;
    private javax.swing.JTextArea totalPetanimal;
    private javax.swing.JComboBox<String> typehousecombo;
    private javax.swing.JComboBox<String> useofhouse;
    private javax.swing.JComboBox<String> wallcombo;
    // End of variables declaration//GEN-END:variables
}
